#!/usr/bin/env bash
# Render.com build script
set -o errexit

pip install -r requirements.txt
python manage.py collectstatic --no-input
python manage.py migrate --no-input
# Seed only if no tutors yet (safe on redeploy)
python manage.py shell -c "
from core.models import Tutor
if Tutor.objects.count() == 0:
    import django.core.management as m
    m.call_command('seed_data')
    print('Seeded initial data')
else:
    print('Data already present, skip seed')
"
