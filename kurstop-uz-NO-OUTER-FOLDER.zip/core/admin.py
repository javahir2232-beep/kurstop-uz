from django.contrib import admin
from .models import Region, Subject, Tutor, Booking, TutorApplication, ContactMessage, SiteStat


@admin.register(Region)
class RegionAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'icon', 'courses_count']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Tutor)
class TutorAdmin(admin.ModelAdmin):
    list_display = ['name', 'subject', 'region', 'format', 'price', 'rating', 'reviews_count', 'is_active', 'is_verified']
    list_filter = ['subject', 'region', 'format', 'is_active', 'is_verified']
    search_fields = ['name', 'bio']
    list_editable = ['is_active', 'is_verified', 'price']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['student_name', 'tutor', 'phone', 'preferred_datetime', 'status', 'created_at']
    list_filter = ['status', 'preferred_datetime']
    search_fields = ['student_name', 'phone']
    list_editable = ['status']
    raw_id_fields = ['tutor']


@admin.register(TutorApplication)
class TutorApplicationAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'subject', 'region', 'phone', 'experience_years', 'price', 'status', 'created_at']
    list_filter = ['status', 'subject', 'region']
    search_fields = ['full_name', 'phone']
    list_editable = ['status']
    readonly_fields = ['created_at']


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ['name', 'phone', 'is_read', 'created_at']
    list_filter = ['is_read']
    search_fields = ['name', 'phone', 'message']
    list_editable = ['is_read']


@admin.register(SiteStat)
class SiteStatAdmin(admin.ModelAdmin):
    list_display = ['label', 'value', 'key', 'order']
    list_editable = ['value', 'order']


from .models import Course, Lesson, LiveSession, Order, Enrollment, LessonProgress


class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 1
    fields = ['order', 'title', 'duration_minutes', 'is_preview', 'video_url']


class LiveSessionInline(admin.TabularInline):
    model = LiveSession
    extra = 0


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['title', 'subject', 'instructor', 'price', 'format', 'level', 'is_published', 'students_count', 'rating']
    list_filter = ['is_published', 'subject', 'format', 'level']
    search_fields = ['title', 'description']
    prepopulated_fields = {'slug': ('title',)}
    list_editable = ['is_published', 'price']
    inlines = [LessonInline, LiveSessionInline]
    raw_id_fields = ['instructor']


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'order', 'duration_minutes', 'is_preview']
    list_filter = ['course', 'is_preview']
    search_fields = ['title']


@admin.register(LiveSession)
class LiveSessionAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'starts_at', 'duration_minutes', 'is_active']
    list_filter = ['is_active', 'course']


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'course', 'guest_name', 'guest_phone', 'amount', 'status', 'provider', 'created_at', 'paid_at']
    list_filter = ['status', 'provider']
    search_fields = ['guest_name', 'guest_phone', 'transaction_id']
    list_editable = ['status']
    raw_id_fields = ['user', 'course']


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ['id', 'course', 'guest_phone', 'is_active', 'progress_percent', 'enrolled_at']
    list_filter = ['is_active', 'course']
    raw_id_fields = ['user', 'course', 'order']


@admin.register(LessonProgress)
class LessonProgressAdmin(admin.ModelAdmin):
    list_display = ['enrollment', 'lesson', 'is_completed', 'watched_seconds']
    list_filter = ['is_completed']
