from django.core.management.base import BaseCommand
from django.utils.text import slugify
from django.utils import timezone
from datetime import timedelta
from core.models import (
    Region, Subject, Tutor, SiteStat,
    Course, Lesson, LiveSession,
)


class Command(BaseCommand):
    help = "KursTop.uz uchun boshlang'ich ma'lumotlarni yuklash"

    def handle(self, *args, **options):
        regions_data = [
            'Toshkent', "Farg'ona", 'Samarqand', 'Andijon', 'Namangan', 'Buxoro'
        ]
        for name in regions_data:
            Region.objects.get_or_create(name=name, defaults={'slug': slugify(name)})

        subjects_data = [
            ('Matematika', 'fa-calculator', 160),
            ('Ingliz tili', 'fa-language', 210),
            ('Fizika', 'fa-atom', 90),
            ('Dasturlash', 'fa-code', 130),
            ('Tarix', 'fa-landmark', 45),
            ('Biologiya', 'fa-dna', 70),
            ('Kimyo', 'fa-flask', 55),
        ]
        for name, icon, count in subjects_data:
            Subject.objects.get_or_create(
                name=name,
                defaults={'slug': slugify(name), 'icon': icon, 'courses_count': count}
            )

        tutors_data = [
            {
                'name': 'Anvar Karimov', 'subject': 'Matematika', 'region': 'Toshkent',
                'format': 'Onlayn', 'experience_years': 7, 'price': 80000,
                'rating': 4.9, 'reviews_count': 42,
                'image_url': 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
                'bio': "Matematika bo'yicha 7 yillik tajriba. DTMga tayyorlash.",
                'is_verified': True,
            },
            {
                'name': 'Malika Ahmedova', 'subject': 'Ingliz tili', 'region': "Farg'ona",
                'format': 'Onlayn', 'experience_years': 5, 'price': 70000,
                'rating': 5.0, 'reviews_count': 58,
                'image_url': 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
                'bio': 'IELTS 8.0. Speaking va Writing bo\'yicha mutaxassis.',
                'is_verified': True,
            },
            {
                'name': 'Jahongir Tursunov', 'subject': 'Fizika', 'region': 'Samarqand',
                'format': 'Oflayn', 'experience_years': 10, 'price': 90000,
                'rating': 4.8, 'reviews_count': 31,
                'image_url': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400',
                'bio': "Fizika olimpiadasi g'olibi.",
                'is_verified': True,
            },
            {
                'name': 'Nigora Aliyeva', 'subject': 'Kimyo', 'region': 'Andijon',
                'format': 'Onlayn', 'experience_years': 4, 'price': 60000,
                'rating': 4.7, 'reviews_count': 19,
                'image_url': 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400',
                'bio': 'Kimyo fanidan chuqurlashtirilgan darslar.',
                'is_verified': True,
            },
            {
                'name': 'Sardor Salimov', 'subject': 'Dasturlash', 'region': 'Toshkent',
                'format': 'Onlayn', 'experience_years': 6, 'price': 120000,
                'rating': 4.9, 'reviews_count': 65,
                'image_url': 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400',
                'bio': 'Python, Django, Frontend. Real loyihalar bilan o\'qitaman.',
                'is_verified': True,
            },
            {
                'name': 'Shaxnoza Umarova', 'subject': 'Biologiya', 'region': 'Namangan',
                'format': 'Oflayn', 'experience_years': 8, 'price': 75000,
                'rating': 4.8, 'reviews_count': 27,
                'image_url': 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400',
                'bio': 'Tibbiyot universitetiga tayyorlash.',
                'is_verified': True,
            },
            {
                'name': 'Dilshod Rakhimov', 'subject': 'Dasturlash', 'region': "Farg'ona",
                'format': 'Onlayn', 'experience_years': 4, 'price': 95000,
                'rating': 4.6, 'reviews_count': 22,
                'image_url': 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400',
                'bio': 'Frontend: React, Next.js.',
                'is_verified': True,
            },
            {
                'name': 'Gulnora Yusupova', 'subject': 'Ingliz tili', 'region': 'Toshkent',
                'format': 'Oflayn', 'experience_years': 9, 'price': 85000,
                'rating': 4.9, 'reviews_count': 71,
                'image_url': 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400',
                'bio': 'Cambridge CELTA. Bolalar va kattalar uchun.',
                'is_verified': True,
            },
        ]

        for t in tutors_data:
            subject = Subject.objects.get(name=t['subject'])
            region = Region.objects.get(name=t['region'])
            Tutor.objects.get_or_create(
                name=t['name'],
                defaults={
                    'subject': subject, 'region': region, 'format': t['format'],
                    'experience_years': t['experience_years'], 'price': t['price'],
                    'rating': t['rating'], 'reviews_count': t['reviews_count'],
                    'image_url': t['image_url'], 'bio': t['bio'],
                    'is_verified': t['is_verified'], 'is_active': True,
                }
            )

        stats = [
            ('tutors', '800+', 'Tajribali ustozlar', 1),
            ('graduates', '15,000+', 'Muvaffaqiyatli bitiruvchilar', 2),
            ('satisfaction', '99%', "Qoniqish ko'rsatkichi", 3),
            ('support', '24/7', "Qo'llab-quvvatlash", 4),
        ]
        for key, value, label, order in stats:
            SiteStat.objects.get_or_create(key=key, defaults={'value': value, 'label': label, 'order': order})

        self.stdout.write(self.style.SUCCESS(
            f'OK: {Region.objects.count()} hudud, {Subject.objects.count()} fan, '
            f'{Tutor.objects.count()} o\'qituvchi, {SiteStat.objects.count()} statistika.'
        ))

        # ── Phase 2: Online courses ──
        courses_seed = [
            {
                'title': 'Python asoslari: noldan ishga',
                'slug': 'python-asoslari',
                'subject': 'Dasturlash',
                'instructor': 'Sardor Salimov',
                'description': "Python dasturlash tilini noldan o'rganing. O'zgaruvchilar, funksiyalar, OOP, fayllar va real mini-loyihalar.",
                'short_description': "Noldan Python — 6 haftalik amaliy kurs",
                'price': 450000,
                'duration_weeks': 6,
                'level': 'beginner',
                'format': 'mixed',
                'lessons': [
                    ("Kirish va o'rnatish", 12, True),
                    ("O'zgaruvchilar va ma'lumot turlari", 25, False),
                    ('Shartlar va tsikllar', 30, False),
                    ('Funksiyalar', 28, False),
                    ("Ro'yxatlar va lug'atlar", 32, False),
                    ('Mini-loyiha: kalkulyator', 40, False),
                ],
            },
            {
                'title': 'IELTS Speaking 7.0+',
                'slug': 'ielts-speaking-70',
                'subject': 'Ingliz tili',
                'instructor': 'Malika Ahmedova',
                'description': 'IELTS Speaking band 7.0 va undan yuqori uchun strategiyalar, amaliy mashqlar va mock testlar.',
                'short_description': "Speaking 7.0+ ga erishish yo'li",
                'price': 380000,
                'duration_weeks': 4,
                'level': 'intermediate',
                'format': 'mixed',
                'lessons': [
                    ('Part 1 strategiyalari', 20, True),
                    ('Part 2: long turn', 25, False),
                    ('Part 3: discussion', 25, False),
                    ('Fluency va pronunciation', 30, False),
                    ('Mock test + feedback', 35, False),
                ],
            },
            {
                'title': 'Matematika: DTM asoslari',
                'slug': 'matematika-dtm',
                'subject': 'Matematika',
                'instructor': 'Anvar Karimov',
                'description': 'DTM va universitet kirish imtihonlariga tayyorgarlik. Algebra, geometriya va masalalar yechish texnikasi.',
                'short_description': 'DTM uchun matematikaga chuqur tayyorgarlik',
                'price': 320000,
                'duration_weeks': 8,
                'level': 'intermediate',
                'format': 'video',
                'lessons': [
                    ('Algebra asoslari takrorlash', 30, True),
                    ('Kvadrat tenglamalar', 35, False),
                    ('Geometriya: uchburchaklar', 40, False),
                    ('Trigonometriya kirish', 35, False),
                    ('Masalalar yechish strategiyasi', 45, False),
                ],
            },
        ]

        for c in courses_seed:
            subject = Subject.objects.get(name=c['subject'])
            tutor = Tutor.objects.filter(name=c['instructor']).first()
            course, created = Course.objects.get_or_create(
                slug=c['slug'],
                defaults={
                    'title': c['title'],
                    'subject': subject,
                    'instructor': tutor,
                    'description': c['description'],
                    'short_description': c['short_description'],
                    'price': c['price'],
                    'duration_weeks': c['duration_weeks'],
                    'level': c['level'],
                    'format': c['format'],
                    'is_published': True,
                    'rating': 4.8,
                }
            )
            if created:
                for i, (ltitle, mins, preview) in enumerate(c['lessons'], 1):
                    Lesson.objects.create(
                        course=course,
                        title=ltitle,
                        order=i,
                        duration_minutes=mins,
                        is_preview=preview,
                        video_url='https://www.youtube.com/watch?v=dQw4w9WgXcQ' if preview else '',
                    )
                LiveSession.objects.create(
                    course=course,
                    title=f'{course.title} — jonli Q&A',
                    starts_at=timezone.now() + timedelta(days=7),
                    duration_minutes=60,
                    meeting_url='https://meet.google.com/demo-kurstop',
                )

        self.stdout.write(self.style.SUCCESS(
            f'Phase2: {Course.objects.count()} kurs, {Lesson.objects.count()} dars yuklandi.'
        ))
