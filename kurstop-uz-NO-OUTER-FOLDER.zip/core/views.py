"""
KursTop.uz — Views
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from django.views.decorators.http import require_POST, require_http_methods
from django.http import JsonResponse
from django.utils.dateparse import parse_datetime
from .models import Tutor, Subject, Region, Booking, TutorApplication, ContactMessage, SiteStat


def home(request):
    """Asosiy sahifa — katalog, filtrlar, statistika"""
    subjects = Subject.objects.all()
    regions = Region.objects.all()
    stats = SiteStat.objects.all()

    # Filters
    subject_slug = request.GET.get('subject', 'all')
    region_slug = request.GET.get('region', 'all')
    fmt = request.GET.get('format', 'all')
    sort = request.GET.get('sort', 'rating')

    tutors = Tutor.objects.filter(is_active=True).select_related('subject', 'region')

    if subject_slug and subject_slug != 'all':
        tutors = tutors.filter(subject__slug=subject_slug)
    if region_slug and region_slug != 'all':
        tutors = tutors.filter(region__slug=region_slug)
    if fmt and fmt != 'all':
        tutors = tutors.filter(format=fmt)

    if sort == 'price-asc':
        tutors = tutors.order_by('price')
    elif sort == 'price-desc':
        tutors = tutors.order_by('-price')
    else:
        tutors = tutors.order_by('-rating', '-reviews_count')

    context = {
        'tutors': tutors,
        'subjects': subjects,
        'regions': regions,
        'stats': stats,
        'current_subject': subject_slug,
        'current_region': region_slug,
        'current_format': fmt,
        'current_sort': sort,
        'tutor_count': tutors.count(),
    }
    return render(request, 'core/home.html', context)


@require_POST
def booking_create(request):
    """Darsga yozilish"""
    tutor_id = request.POST.get('tutor_id')
    student_name = request.POST.get('student_name', '').strip()
    phone = request.POST.get('phone', '').strip()
    preferred = request.POST.get('preferred_datetime', '')
    note = request.POST.get('note', '').strip()

    if not all([tutor_id, student_name, phone, preferred]):
        messages.error(request, 'Barcha majburiy maydonlarni to\'ldiring.')
        return redirect('home')

    tutor = get_object_or_404(Tutor, pk=tutor_id, is_active=True)
    dt = parse_datetime(preferred.replace('T', ' '))
    if not dt:
        # HTML datetime-local format
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(preferred)
        except Exception:
            messages.error(request, 'Vaqt formati noto\'g\'ri.')
            return redirect('home')

    Booking.objects.create(
        tutor=tutor,
        student_name=student_name,
        phone=phone,
        preferred_datetime=dt,
        note=note,
    )
    messages.success(request, f'Kurstop.uz orqali "{tutor.name}" darsiga yozilish so\'rovingiz qabul qilindi!')
    return redirect('home')


@require_POST
def tutor_apply(request):
    """O'qituvchi arizasi"""
    full_name = request.POST.get('full_name', '').strip()
    subject_id = request.POST.get('subject_id')
    phone = request.POST.get('phone', '').strip()
    experience = request.POST.get('experience_years')
    price = request.POST.get('price')
    region_id = request.POST.get('region_id')
    bio = request.POST.get('bio', '').strip()

    if not all([full_name, subject_id, phone, experience, price, region_id, bio]):
        messages.error(request, 'Barcha maydonlarni to\'ldiring.')
        return redirect('home')

    subject = get_object_or_404(Subject, pk=subject_id)
    region = get_object_or_404(Region, pk=region_id)

    TutorApplication.objects.create(
        full_name=full_name,
        subject=subject,
        phone=phone,
        experience_years=int(experience),
        price=int(price),
        region=region,
        bio=bio,
    )
    messages.success(request, 'Kurstop.uz ustozlar safiga ariza yuborildi! Tez orada bog\'lanamiz.')
    return redirect('home')


@require_POST
def contact_submit(request):
    """Aloqa formasi"""
    name = request.POST.get('name', '').strip()
    phone = request.POST.get('phone', '').strip()
    message = request.POST.get('message', '').strip()

    if not all([name, phone, message]):
        messages.error(request, 'Barcha maydonlarni to\'ldiring.')
        return redirect('home')

    ContactMessage.objects.create(name=name, phone=phone, message=message)
    messages.success(request, 'Xabaringiz yuborildi! Kurstop.uz 24/7 xizmati tezda javob beradi.')
    return redirect('home')


from django.utils import timezone
from django.utils.text import slugify
from .models import Course, Lesson, Order, Enrollment, LessonProgress


def course_list(request):
    """Onlayn kurslar katalogi"""
    courses = Course.objects.filter(is_published=True).select_related('subject', 'instructor')
    subject_slug = request.GET.get('subject', 'all')
    if subject_slug and subject_slug != 'all':
        courses = courses.filter(subject__slug=subject_slug)

    subjects = Subject.objects.all()
    return render(request, 'core/course_list.html', {
        'courses': courses,
        'subjects': subjects,
        'current_subject': subject_slug,
    })


def course_detail(request, slug):
    """Kurs sahifasi"""
    course = get_object_or_404(
        Course.objects.select_related('subject', 'instructor').prefetch_related('lessons', 'live_sessions'),
        slug=slug, is_published=True
    )
    return render(request, 'core/course_detail.html', {'course': course})


@require_POST
def course_purchase(request, slug):
    """
    Mock to'lov: Order yaratadi, status=paid qiladi, Enrollment ochadi.
    Real Payme/Click callback keyinroq ulanadi.
    """
    course = get_object_or_404(Course, slug=slug, is_published=True)
    name = request.POST.get('name', '').strip()
    phone = request.POST.get('phone', '').strip()
    email = request.POST.get('email', '').strip()

    if not name or not phone:
        messages.error(request, 'Ism va telefon majburiy.')
        return redirect('course_detail', slug=slug)

    order = Order.objects.create(
        course=course,
        amount=course.price,
        guest_name=name,
        guest_phone=phone,
        guest_email=email,
        status='pending',
        provider='mock',
    )

    # ── Mock payment success (productionda callback orqali) ──
    order.status = 'paid'
    order.transaction_id = f'MOCK-{order.pk}-{timezone.now().strftime("%Y%m%d%H%M%S")}'
    order.paid_at = timezone.now()
    order.save()

    enrollment = Enrollment.objects.create(
        course=course,
        order=order,
        guest_phone=phone,
        is_active=True,
    )

    # Progress yozuvlari (barcha darslar)
    for lesson in course.lessons.all():
        LessonProgress.objects.get_or_create(enrollment=enrollment, lesson=lesson)

    course.students_count = course.enrollments.filter(is_active=True).count()
    course.save(update_fields=['students_count'])

    messages.success(
        request,
        f'"{course.title}" kursi muvaffaqiyatli xarid qilindi! Kabinetga o\'ting.'
    )
    return redirect('cabinet', enrollment_id=enrollment.pk)


def cabinet(request, enrollment_id):
    """O'quvchi kabineti — progress va darslar"""
    enrollment = get_object_or_404(
        Enrollment.objects.select_related('course', 'order')
        .prefetch_related('lesson_progress__lesson', 'course__lessons', 'course__live_sessions'),
        pk=enrollment_id, is_active=True
    )
    progress_list = enrollment.lesson_progress.select_related('lesson').order_by('lesson__order')
    completed = progress_list.filter(is_completed=True).count()
    total = progress_list.count() or 1
    percent = int(completed / total * 100)
    if enrollment.progress_percent != percent:
        enrollment.progress_percent = percent
        enrollment.save(update_fields=['progress_percent'])

    return render(request, 'core/cabinet.html', {
        'enrollment': enrollment,
        'progress_list': progress_list,
        'completed': completed,
        'total': total,
        'percent': percent,
    })


@require_POST
def mark_lesson_done(request, enrollment_id, lesson_id):
    """Darsni yakunlash"""
    enrollment = get_object_or_404(Enrollment, pk=enrollment_id, is_active=True)
    progress = get_object_or_404(LessonProgress, enrollment=enrollment, lesson_id=lesson_id)
    progress.is_completed = True
    progress.completed_at = timezone.now()
    progress.save()
    messages.success(request, 'Dars yakunlandi!')
    return redirect('cabinet', enrollment_id=enrollment_id)
