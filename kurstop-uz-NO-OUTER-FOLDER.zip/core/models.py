"""
KursTop.uz — Core models
Startup-level data model for tutors, bookings, applications, contacts
"""

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Region(models.Model):
    name = models.CharField('Hudud', max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)

    class Meta:
        verbose_name = 'Hudud'
        verbose_name_plural = 'Hududlar'
        ordering = ['name']

    def __str__(self):
        return self.name


class Subject(models.Model):
    name = models.CharField('Fan / Yo\'nalish', max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)
    icon = models.CharField('Ikonka (FontAwesome)', max_length=50, default='fa-book')
    courses_count = models.PositiveIntegerField('Kurslar soni (display)', default=0)

    class Meta:
        verbose_name = 'Fan'
        verbose_name_plural = 'Fanlar'
        ordering = ['name']

    def __str__(self):
        return self.name


class Tutor(models.Model):
    FORMAT_CHOICES = [
        ('Onlayn', 'Onlayn'),
        ('Oflayn', 'Oflayn'),
        ('Gibrid', 'Gibrid'),
    ]

    name = models.CharField('Ism-familiya', max_length=150)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT, related_name='tutors', verbose_name='Fan')
    region = models.ForeignKey(Region, on_delete=models.PROTECT, related_name='tutors', verbose_name='Hudud')
    format = models.CharField('Format', max_length=20, choices=FORMAT_CHOICES, default='Onlayn')
    experience_years = models.PositiveIntegerField('Tajriba (yil)', default=1)
    price = models.PositiveIntegerField('Soatbay narx (so\'m)', help_text='So\'mda')
    rating = models.DecimalField(
        'Reyting', max_digits=2, decimal_places=1, default=5.0,
        validators=[MinValueValidator(1.0), MaxValueValidator(5.0)]
    )
    reviews_count = models.PositiveIntegerField('Sharhlar soni', default=0)
    bio = models.TextField('Bio / Tavsif', blank=True)
    image_url = models.URLField('Rasm URL', blank=True, default='')
    phone = models.CharField('Telefon', max_length=20, blank=True)
    is_active = models.BooleanField('Faol', default=True)
    is_verified = models.BooleanField('Tasdiqlangan', default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'O\'qituvchi'
        verbose_name_plural = 'O\'qituvchilar'
        ordering = ['-rating', '-reviews_count']

    def __str__(self):
        return f'{self.name} — {self.subject.name}'

    @property
    def experience_display(self):
        return f'{self.experience_years} yil'

    @property
    def price_display(self):
        return f'{self.price:,}'.replace(',', ' ')


class Booking(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Kutilmoqda'),
        ('confirmed', 'Tasdiqlangan'),
        ('cancelled', 'Bekor qilingan'),
        ('completed', 'Yakunlangan'),
    ]

    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE, related_name='bookings', verbose_name='O\'qituvchi')
    student_name = models.CharField('O\'quvchi ismi', max_length=150)
    phone = models.CharField('Telefon', max_length=20)
    preferred_datetime = models.DateTimeField('Qulay vaqt')
    note = models.TextField('Izoh', blank=True)
    status = models.CharField('Holat', max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Bron / Yozilish'
        verbose_name_plural = 'Bronlar'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.student_name} → {self.tutor.name}'


class TutorApplication(models.Model):
    STATUS_CHOICES = [
        ('new', 'Yangi'),
        ('reviewing', 'Ko\'rib chiqilmoqda'),
        ('approved', 'Tasdiqlangan'),
        ('rejected', 'Rad etilgan'),
    ]

    full_name = models.CharField('To\'liq ism', max_length=150)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT, verbose_name='Fan')
    phone = models.CharField('Telefon', max_length=20)
    experience_years = models.PositiveIntegerField('Tajriba (yil)')
    price = models.PositiveIntegerField('Soatbay narx')
    region = models.ForeignKey(Region, on_delete=models.PROTECT, verbose_name='Hudud')
    bio = models.TextField('Bio')
    status = models.CharField('Holat', max_length=20, choices=STATUS_CHOICES, default='new')
    created_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField('Admin izohi', blank=True)

    class Meta:
        verbose_name = 'O\'qituvchi arizasi'
        verbose_name_plural = 'O\'qituvchi arizalari'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.full_name} ({self.subject.name})'


class ContactMessage(models.Model):
    name = models.CharField('Ism', max_length=100)
    phone = models.CharField('Telefon', max_length=20)
    message = models.TextField('Xabar')
    is_read = models.BooleanField('O\'qilgan', default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Aloqa xabari'
        verbose_name_plural = 'Aloqa xabarlari'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} — {self.created_at:%d.%m.%Y}'


class SiteStat(models.Model):
    """Static display stats for homepage"""
    key = models.CharField(max_length=50, unique=True)
    value = models.CharField(max_length=50)
    label = models.CharField(max_length=100)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f'{self.label}: {self.value}'


# ──────────────────────────────────────────────
# PHASE 2: Online Courses, Orders, Enrollment
# ──────────────────────────────────────────────

from django.conf import settings


class Course(models.Model):
    LEVEL_CHOICES = [
        ('beginner', 'Boshlang\'ich'),
        ('intermediate', 'O\'rta'),
        ('advanced', 'Yuqori'),
    ]
    FORMAT_CHOICES = [
        ('video', 'Video darslar'),
        ('live', 'Jonli darslar'),
        ('mixed', 'Video + Jonli'),
    ]

    title = models.CharField('Kurs nomi', max_length=200)
    slug = models.SlugField(max_length=220, unique=True)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT, related_name='courses')
    instructor = models.ForeignKey(
        Tutor, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='courses', verbose_name='O\'qituvchi'
    )
    description = models.TextField('Tavsif')
    short_description = models.CharField('Qisqa tavsif', max_length=300, blank=True)
    price = models.PositiveIntegerField('Narx (so\'m)')
    duration_weeks = models.PositiveIntegerField('Davomiylik (hafta)', default=4)
    level = models.CharField('Daraja', max_length=20, choices=LEVEL_CHOICES, default='beginner')
    format = models.CharField('Format', max_length=20, choices=FORMAT_CHOICES, default='video')
    cover_image = models.URLField('Muqova rasm', blank=True)
    is_published = models.BooleanField('Nashr etilgan', default=False)
    students_count = models.PositiveIntegerField('O\'quvchilar soni', default=0)
    rating = models.DecimalField('Reyting', max_digits=2, decimal_places=1, default=5.0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Onlayn kurs'
        verbose_name_plural = 'Onlayn kurslar'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    @property
    def price_display(self):
        return f'{self.price:,}'.replace(',', ' ')


class Lesson(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField('Dars nomi', max_length=200)
    order = models.PositiveIntegerField('Tartib', default=1)
    video_url = models.URLField('Video havola', blank=True, help_text='YouTube/Vimeo yoki hosting URL')
    duration_minutes = models.PositiveIntegerField('Davomiylik (daqiqa)', default=15)
    is_preview = models.BooleanField('Bepul preview', default=False)
    content = models.TextField('Qo\'shimcha material / matn', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Dars'
        verbose_name_plural = 'Darslar'
        ordering = ['course', 'order']
        unique_together = ['course', 'order']

    def __str__(self):
        return f'{self.course.title} — {self.order}. {self.title}'


class LiveSession(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='live_sessions')
    title = models.CharField('Mavzu', max_length=200)
    starts_at = models.DateTimeField('Boshlanish vaqti')
    duration_minutes = models.PositiveIntegerField(default=60)
    meeting_url = models.URLField('Uchrashuv havolasi', blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Jonli dars'
        verbose_name_plural = 'Jonli darslar'
        ordering = ['starts_at']

    def __str__(self):
        return f'{self.title} ({self.starts_at:%d.%m.%Y %H:%M})'


class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Kutilmoqda'),
        ('paid', 'To\'langan'),
        ('failed', 'Muvaffaqiyatsiz'),
        ('refunded', 'Qaytarilgan'),
        ('cancelled', 'Bekor qilingan'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='orders', null=True, blank=True
    )
    # Guest checkout support
    guest_name = models.CharField('Ism', max_length=150, blank=True)
    guest_phone = models.CharField('Telefon', max_length=20, blank=True)
    guest_email = models.EmailField(blank=True)

    course = models.ForeignKey(Course, on_delete=models.PROTECT, related_name='orders')
    amount = models.PositiveIntegerField('Summa (so\'m)')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    provider = models.CharField('To\'lov tizimi', max_length=30, blank=True, help_text='payme / click / mock')
    transaction_id = models.CharField('Tranzaksiya ID', max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'Buyurtma'
        verbose_name_plural = 'Buyurtmalar'
        ordering = ['-created_at']

    def __str__(self):
        name = self.guest_name or (self.user.get_full_name() if self.user else '—')
        return f'#{self.pk} {name} — {self.course.title} ({self.status})'


class Enrollment(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='enrollments', null=True, blank=True
    )
    guest_phone = models.CharField(max_length=20, blank=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    order = models.OneToOneField(Order, on_delete=models.SET_NULL, null=True, blank=True, related_name='enrollment')
    is_active = models.BooleanField(default=True)
    progress_percent = models.PositiveIntegerField(default=0)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'Yozilish (Enrollment)'
        verbose_name_plural = 'Yozilishlar'
        ordering = ['-enrolled_at']

    def __str__(self):
        return f'{self.course.title} — {self.progress_percent}%'


class LessonProgress(models.Model):
    enrollment = models.ForeignKey(Enrollment, on_delete=models.CASCADE, related_name='lesson_progress')
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    watched_seconds = models.PositiveIntegerField(default=0)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ['enrollment', 'lesson']
        verbose_name = 'Dars progressi'
        verbose_name_plural = 'Darslar progressi'

    def __str__(self):
        return f'{self.lesson.title} — {"✓" if self.is_completed else "…"}'
