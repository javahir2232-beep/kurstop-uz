# Kurstop.uz — Render.com ga deploy

## 1-usul: Blueprint (tavsiya)

1. GitHub ga loyihani yuklang (yoki zip dan yangi repo yarating).
2. [Render Dashboard](https://dashboard.render.com) → **New** → **Blueprint**
3. GitHub reponi ulang, `render.yaml` avtomatik o‘qiladi.
4. **Apply** → PostgreSQL + Web service yaratiladi.
5. Deploy tugagach: `https://kurstop-uz.onrender.com` (yoki berilgan URL).

## 2-usul: Qo‘lda

### A) Web Service
1. **New** → **Web Service** → repo yoki public Git
2. Sozlamalar:
   - **Runtime**: Python 3
   - **Build Command**: `./build.sh`
   - **Start Command**: `gunicorn kurstop.wsgi:application --bind 0.0.0.0:$PORT`
3. Environment Variables:
   | Key | Value |
   |-----|--------|
   | `SECRET_KEY` | (Generate) |
   | `DEBUG` | `False` |
   | `ALLOWED_HOSTS` | `.onrender.com` yoki to‘liq domen |
   | `DATABASE_URL` | PostgreSQL ulanish (pastda) |

### B) PostgreSQL
1. **New** → **PostgreSQL** (Free)
2. **Internal Database URL** ni nusxalang → Web Service `DATABASE_URL` ga qo‘ying.

## Deploy dan keyin

1. Admin yaratish (Render Shell):
   ```bash
   python manage.py createsuperuser
   ```
2. Yoki birinchi deploy da `seed_data` ishlaydi (agar bo‘sh bo‘lsa).
3. Admin: `https://SIZNING-URL.onrender.com/admin/`

## Muhim

- Free plan “uyquga ketadi” (~15 min inactivity) — birinchi so‘rov sekin bo‘lishi mumkin.
- `SECRET_KEY` ni hech qachon kodga yozmang — faqat env.
- Custom domen: Render → Settings → Custom Domains + `ALLOWED_HOSTS` ga qo‘shing.

## Lokal tekshirish

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_data
python manage.py runserver
```
