from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('booking/', views.booking_create, name='booking_create'),
    path('tutor-apply/', views.tutor_apply, name='tutor_apply'),
    path('contact/', views.contact_submit, name='contact_submit'),
    path('kurslar/', views.course_list, name='course_list'),
    path('kurslar/<slug:slug>/', views.course_detail, name='course_detail'),
    path('kurslar/<slug:slug>/xarid/', views.course_purchase, name='course_purchase'),
    path('kabinet/<int:enrollment_id>/', views.cabinet, name='cabinet'),
    path('kabinet/<int:enrollment_id>/dars/<int:lesson_id>/yakunlash/', views.mark_lesson_done, name='mark_lesson_done'),
]

# Media only in DEBUG (production: use S3 or similar)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
