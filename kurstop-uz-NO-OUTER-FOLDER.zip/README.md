# Kurstop.uz — Django MVP (Render-ready)

O'zbekiston ta'lim platformasi: repetitorlar + onlayn kurslar.

## Tezkor start (lokal)

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_data
python manage.py createsuperuser
python manage.py runserver
```

- Sayt: http://127.0.0.1:8000/
- Kurslar: http://127.0.0.1:8000/kurslar/
- Admin: http://127.0.0.1:8000/admin/

## Render.com deploy

To‘liq qo‘llanma: **[DEPLOY.md](DEPLOY.md)**

Qisqacha:
1. GitHub ga push
2. Render → New → Blueprint → `render.yaml`
3. Yoki Web Service + PostgreSQL qo‘lda

## Tuzilma

```
├── manage.py
├── requirements.txt
├── Procfile
├── build.sh
├── render.yaml
├── DEPLOY.md
├── kurstop/          # settings, urls, wsgi
├── core/             # models, views, admin, seed
└── templates/core/   # home, courses, cabinet
```

## Funksiyalar

**Phase 1:** Repetitor katalogi, filtr, bron, ariza, aloqa  
**Phase 2:** Onlayn kurslar, mock to‘lov, enrollment, kabinet, progress  

© 2026 Kurstop.uz
